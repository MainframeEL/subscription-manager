This directory is intended for caching of large files downloaded by Ansible
scripts (e.g. ISO images). If Ansible script will download any new file
to this directory, then don't forget to update `.gitignore` file.