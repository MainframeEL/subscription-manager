#! /usr/bin/python

from __future__ import print_function, division, absolute_import

from subscription_manager.base_plugin import SubManPlugin

requires_api_version = "0.0"


class OldApiVersionPlugin(SubManPlugin):
    pass
