#! /usr/bin/python
from __future__ import print_function, division, absolute_import

from subscription_manager.base_plugin import SubManPlugin


class NoApiVersionPlugin(SubManPlugin):
    pass
