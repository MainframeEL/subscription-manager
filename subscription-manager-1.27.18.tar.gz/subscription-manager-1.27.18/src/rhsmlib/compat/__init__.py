from __future__ import print_function, division, absolute_import

from rhsmlib.compat.subprocess_compat import check_output  # NOQA
