?package(subscription-manager):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="subscription-manager" command="/usr/bin/subscription-manager"
